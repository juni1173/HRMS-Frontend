import CandidateList from "./Components/CandidateList"
const Candidates = () => {
    return (
        <CandidateList />
    )
}
export default Candidates